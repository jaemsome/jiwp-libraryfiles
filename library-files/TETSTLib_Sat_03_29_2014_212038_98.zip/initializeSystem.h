
void initializeSystem(void);
