
// this routine setups up pins for the pwm outputs
// pwmOut 0-4 pwmout number to use.
// pin which pin to output it on.
void pwmOutPins(unsigned char pwmOut, unsigned char pin);
