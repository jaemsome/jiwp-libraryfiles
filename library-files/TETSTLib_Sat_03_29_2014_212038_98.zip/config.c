/*********************************************************
 *
 * file: config.c 
 *
 * Author:  Kim Mansfield
 * Date: 3/29/2014
 * Copyright KMI Technology
 *
 * Synopsis: This routine provides the configuration bits for
 * the processor.  This allows the processor to run serial ports
 * and USB without a crystal.  You just have to include this in
 * your project.
 *
 *********************************************************/

#include <p24fxxxx.h>

/** CONFIGURATION **************************************************/
_CONFIG1(JTAGEN_OFF & GCP_OFF & GWRP_OFF & ICS_PGx1 & FWDTEN_OFF & WINDIS_OFF & FWPSA_PR32 & WDTPS_PS8192)
_CONFIG2(IESO_OFF & FNOSC_FRCPLL & OSCIOFNC_ON & POSCMOD_NONE & PLL96MHZ_ON & PLLDIV_DIV2 & FCKSM_CSDCMD & IOL1WAY_OFF)
_CONFIG3(WPFP_WPFP0 & SOSCSEL_IO & WUTSEL_FST & WPDIS_WPDIS & WPCFG_WPCFGDIS & WPEND_WPENDMEM)
_CONFIG4(DSWDTPS_DSWDTPS3 & DSWDTOSC_LPRC & RTCOSC_LPRC & DSBOREN_OFF & DSWDTEN_OFF)
