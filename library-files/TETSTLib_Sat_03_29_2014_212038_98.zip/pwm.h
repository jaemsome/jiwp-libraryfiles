
void pwmInit(void);
void analogWrite(unsigned char pin, unsigned int value);
void pwmPins(unsigned int pin);
