
void uart2PinsInclude(void);
void uart2Pins(unsigned char rx, unsigned char tx);
