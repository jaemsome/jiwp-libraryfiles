
void uart1Pins(unsigned char rx, unsigned char tx);
