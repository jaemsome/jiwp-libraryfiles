
void i2cInit(int BRG);
void i2c_start(void);
void i2c_restart(void);
void reset_i2c_bus(void);
char send_i2c_byte(int data);
char i2c_read(void);
char i2c_read_ack(void);
void I2Cwrite(char addr, char subaddr, char value);
char I2Cread(char addr, char subaddr);
unsigned char I2Cpoll(char addr);
unsigned int i2cQueue(unsigned char readWrite, 
      unsigned char address, 
      unsigned char *location, 
      unsigned char locLength,
      unsigned char *buffer,
      unsigned char length,
      unsigned char *error,
      fp task);

//#define SPEED100K 0x4F
#define SPEED100K 0x9E
#define SPEED400K 0x13
#define SPEED1MHZ 0X07

