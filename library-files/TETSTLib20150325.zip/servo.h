
void servoInit(void);
void servoWrite(unsigned char pin, unsigned int value);
void servoPin(unsigned int pin);
