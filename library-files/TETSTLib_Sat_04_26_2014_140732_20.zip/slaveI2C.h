
void slaveI2CInit(unsigned char add);
void slaveI2CPut(unsigned char *data, unsigned int length);
void slaveI2CGet(unsigned char *data, unsigned int length);
