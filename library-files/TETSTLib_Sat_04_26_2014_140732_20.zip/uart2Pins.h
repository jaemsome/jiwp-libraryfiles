
void uart2Pins(unsigned char rx, unsigned char tx);
