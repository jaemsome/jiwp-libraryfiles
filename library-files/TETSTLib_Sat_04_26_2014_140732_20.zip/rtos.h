#ifndef RTOSFIRST
#define RTOSFIRST

#define MAXQUEUE 32
#define MAXEVENTS 32
typedef void (*fp)(void);

void declareTimer1(void);
int delayMS(fp task,unsigned int length);
void runTask(fp task);
void runNext(void);
void RTOSInit(void);
int queueSerial1(fp task);
void declareSPort1(void);
int queueSerial2(fp task);
void declareSPort2(void);
void declareSTPort1(void);
int queueUSB(fp task);
void declareUSB(void);
int eventSI2CRead(fp task);
void declareSI2CWrite(void);
void declareSI2CRead(void);

#ifdef RTOSDEFINE
fp runQueue[MAXQUEUE] = {0};
fp waitTimer1[MAXQUEUE] = {0};
unsigned int waitDelay[MAXQUEUE] = {0};
fp waitEvent[MAXEVENTS][MAXQUEUE];
fp waitSPort1 = 0;
fp waitSPort2 = 0;
fp waitSTPort1 = 0;
fp waitUSB = 0;
fp waitSI2CRead = 0;
fp waitSI2CWrite = 0;
#else

#endif
#endif
