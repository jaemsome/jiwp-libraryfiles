/* 
 * File:   main.c
 * Author: kmansfie
 *
 * Created on September 23, 2014, 7:51 AM
 */

//#include <stdio.h>
//#include <stdlib.h>

#include <p24fxxxx.h>
#include "rtos.h"
#include "pins.h"
#include "initializeSystem.h"

unsigned int on = 0;

//
/******************************************************************************
 * Function void blink(void)
 *
 * This function is called by the RTOS when the delay has expired.  Interesting
 * to note that you have to call the delay routine again to get another delay.
 * The LED is flashed in this routine.
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    blinks the LED and also toggles the on variable between 1 and
 *                  0.
 *
 *****************************************************************************/
void
blink(void)
{
  if (on)
  {
    digitalWrite(16,HIGH);
    on = 0;
  }
  else
  {
    digitalWrite(16,LOW);
    on = 1;
  }
  if (!delayMS(blink,500))
  {
    runNext(); // next item to be run
    // wasn't able to add to the delay queue.  It must be full.
    // Try again.
    while (!delayMS(blink,500))
      runNext();
    // or you could setup an infinite loop to catch the error in
    // a debugger.
    // while (1)
    //    ;
  }
}

/******************************************************************************
 * Function:        void main(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        Main program entry point.
 *
 * Note:            None
 *****************************************************************************/
int main(void)
{
  initializeSystem();

  pinMode(16, OUTPUT);

  while (!delayMS(blink,500))
    runNext();

  while(1)
  {
    runNext();
  }//end while
}//end main


